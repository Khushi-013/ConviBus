//import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.convi.R
//import com.example.convi.RealTimeTrackingActivity
//import com.google.firebase.auth.FirebaseAuth

class ForgotPasswordActivity : AppCompatActivity() {
    private lateinit var emailEditText: EditText
    //private val auth = FirebaseAuth.getInstance()
    private lateinit var errorTextView: TextView // Add this field

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        emailEditText = findViewById(R.id.forgotPasswordEmail)
        //errorTextView = findViewById(R.id.errorTextView) // Initialize the error TextView

        val resetButton: Button = findViewById(R.id.resetButton)

        /*resetButton.setOnClickListener {
            val email = emailEditText.text.toString()

            // Send a password reset email using Firebase Authentication
            auth.sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // Password reset email sent successfully
                        // You can inform the user and navigate back to the login page
                        val intent = Intent(this@ForgotPasswordActivity, RealTimeTrackingActivity::class.java)
                        startActivity(intent)
                    } else {
                        // Password reset email sending failed
                        // Handle the error and show an error message to the user
                        val errorMessage = task.exception?.message ?: "Password reset failed."
                        showError(errorMessage)
                    }
                }
        }*/
    }

    // Helper function to show error messages to the user
    private fun showError(message: String) {
        errorTextView.text = message
    }
}



