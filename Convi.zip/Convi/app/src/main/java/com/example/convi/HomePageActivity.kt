package com.example.convi

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity



class HomePageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homepage)

        findViewById<Button>(R.id.driver_login_button).setOnClickListener {
            val intent = Intent(this, DriverActivity::class.java)
            startActivity(intent)

        }
        findViewById<Button>(R.id.passenger_login_button).setOnClickListener {
            val intent = Intent(this, NearbyBusesActivity::class.java)
            startActivity(intent)
        }
        findViewById<ImageView>(R.id.scheduleList).setOnClickListener {
            val intent = Intent(this, TargetActivity::class.java)
            startActivity(intent)
        }
    }
}