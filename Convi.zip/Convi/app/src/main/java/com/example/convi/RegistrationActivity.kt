package com.example.convi

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class RegistrationActivity : AppCompatActivity() {
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        usernameEditText = findViewById(R.id.registrationUsername)
        passwordEditText = findViewById(R.id.registrationPassword)

        val registerButton: Button = findViewById(R.id.registerButton)

        registerButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Perform user registration logic here (e.g., create a new user account)
            // You can use Firebase Authentication or your preferred registration mechanism

            // After successful registration, navigate back to the login page
            val intent = Intent(this@RegistrationActivity, RealTimeTrackingActivity::class.java)
            startActivity(intent)
        }
    }
}

