package com.example.convi

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import androidx.cardview.widget.CardView

class TargetActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_target_activity)

        val cardView = findViewById<CardView>(R.id.button)
        cardView.setOnClickListener {
            findViewById<Button>(R.id.button).setOnClickListener {
                val intent = Intent(this, MapActivity::class.java)
                startActivity(intent)
            }
        }
    }
}