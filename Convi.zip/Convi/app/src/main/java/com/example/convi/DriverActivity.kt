package com.example.convi

import ForgotPasswordActivity
import android.content.Intent
import android.os.Bundle
import android.util.Log // Import Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DriverActivity : AppCompatActivity() {
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver)

        usernameEditText = findViewById(R.id.username)
        passwordEditText = findViewById(R.id.password)

        findViewById<Button>(R.id.loginButton).setOnClickListener {
            val intent = Intent(this, com.example.convi.RealTimeTrackingActivity::class.java)
            startActivity(intent)

        }

        val loginButton: Button = findViewById(R.id.loginButton)
        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Validate credentials
            if (isValid(username, password)) {
                // Successful login
                // Handle the login logic here
                showLoggedInMessage()

                // Log before navigating
                Log.d("com.example.convi.DriverActivity", "Before navigation to RealTimeTrackingActivity")

                // Navigate to RealTimeTrackingActivity
                val i = Intent(this@DriverActivity, RealTimeTrackingActivity::class.java)
                startActivity(i)

                // Log after navigating
                Log.d("com.example.convi.DriverActivity", "After navigation to RealTimeTrackingActivity")
            } else {
                // Login failed
                showLoginFailedMessage()
                showToast("Invalid username or password")
            }
        }

        // Handle registration and forgot password links here (if needed)
        val registerButton: TextView = findViewById(R.id.registerLink)
        registerButton.setOnClickListener {
            // Navigate to the RegistrationActivity
            val intent = Intent(this@DriverActivity, RegistrationActivity::class.java)
            startActivity(intent)
        }
        val forgotPasswordButton: TextView = findViewById(R.id.forgotPasswordLink)
        forgotPasswordButton.setOnClickListener {
            // Navigate to the ForgotPasswordActivity
            val intent = Intent(this@DriverActivity, ForgotPasswordActivity::class.java)
            startActivity(intent)
        }
    }

    private fun isValid(username: String, password: String): Boolean {
        // Replace these with actual driver credentials stored in your application
        val validUsername = "Khushi"
        val validPassword = "Khushi@123"

        return username == validUsername && password == validPassword
    }

    private fun showLoggedInMessage() {
        showToast("Logged in successfully")
    }

    private fun showLoginFailedMessage() {
        showToast("Invalid username or password. Please try again.")
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

