package com.example.convi

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition

class NearbyBusesActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var mapView: MapView
    private lateinit var sourceSpinner: Spinner
    private lateinit var destinationSpinner: Spinner // Declare the destinationSpinner
    private lateinit var googleMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nearby_buses)

        findViewById<Button>(R.id.viewAll).setOnClickListener {
            val intent = Intent(this, TargetActivity::class.java)
            startActivity(intent)
        }
        findViewById<ImageView>(R.id.scheduleList).setOnClickListener {
            val intent = Intent(this, TargetActivity::class.java)
            startActivity(intent)
        }


            mapView = findViewById(R.id.mapView)
            sourceSpinner = findViewById(R.id.sourceSpinner)
            destinationSpinner =
                findViewById(R.id.destinationSpinner) // Initialize the destinationSpinner


            mapView.onCreate(savedInstanceState)
            mapView.getMapAsync(this)

            // Populate the Spinner with data
            val sourceOptions = arrayOf("Boisar", "Pune", "Karad", "Kolhapur", "Satara", "Nashik")

            val sourceAdapter =
                ArrayAdapter(this, android.R.layout.simple_spinner_item, sourceOptions)
            sourceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            sourceSpinner.adapter = sourceAdapter

            // Set an item selected listener for sourceSpinner
            sourceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    // Handle the case where nothing is selected in sourceSpinner
                }
            }


            // Populate the Spinner with data
            val destinationOptions =
                arrayOf("Boisar", "Pune", "Karad", "Kolhapur", "Satara", "Nashik")

            val destinationAdapter =
                ArrayAdapter(this, android.R.layout.simple_spinner_item, destinationOptions)
            destinationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            destinationSpinner.adapter = destinationAdapter

            // Set an item selected listener for destinationSpinner
            destinationSpinner.onItemSelectedListener =
                object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>?,
                        view: View?,
                        position: Int,
                        id: Long
                    ) {
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {
                        // Handle the case where nothing is selected in destinationSpinner
                    }
                }
        }

        override fun onMapReady(gMap: GoogleMap) {
            googleMap = gMap // Initialize the googleMap property

            // Add code to configure and interact with the GoogleMap here.

            // For example, you can set the map type:
            googleMap.mapType = GoogleMap.MAP_TYPE_NORMAL
            val sourceLatitude = 37.7749
            val sourceLongitude = -122.4194
            val destinationLatitude = 37.7750
            val destinationLongitude = -122.4195

            // You can also add markers for source and destination (replace latLngSource and latLngDestination with your coordinates):
            val latLngSource = LatLng(sourceLatitude, sourceLongitude)
            val latLngDestination = LatLng(destinationLatitude, destinationLongitude)

            val sourceMarker = MarkerOptions()
                .position(latLngSource)
                .title("Source")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))

            val destinationMarkerOptions = MarkerOptions()
                .position(latLngDestination)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))

            val destinationMarker = googleMap.addMarker(destinationMarkerOptions)
            destinationMarker?.title = "Destination"

            googleMap.addMarker(sourceMarker)?.title = "Source"



            // You can also move the camera to a specific location or set the zoom level:
            val cameraPosition = CameraPosition.Builder().target(latLngSource).zoom(14.0f).build()
            val cameraUpdate = CameraUpdateFactory.newCameraPosition(cameraPosition)
            googleMap.moveCamera(cameraUpdate)
        }
    }


