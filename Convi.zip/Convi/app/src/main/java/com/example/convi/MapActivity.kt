package com.example.convi

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MapActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        // Replace these coordinates with your source and destination coordinates
        val sourceLat = 37.7749
        val sourceLng = -122.4194
        val destLat = 34.0522
        val destLng = -118.2437

        // Create a Uri with the source and destination coordinates for directions
        val uri = Uri.parse("https://www.google.com/maps/dir/?api=1&origin=$sourceLat,$sourceLng&destination=$destLat,$destLng")

        // Create an intent to open a maps application with the directions
        val mapIntent = Intent(Intent.ACTION_VIEW, uri)
        mapIntent.setPackage("com.google.android.apps.maps") // Use Google Maps app

        // Check if a maps application is available on the device
        if (mapIntent.resolveActivity(packageManager) != null) {
            startActivity(mapIntent)
        } else {
            // If no maps app is available, you can provide an alternative action, like showing a toast or providing a link to open in a web browser.
            // Handle this case according to your app's requirements.
        }
    }
}


